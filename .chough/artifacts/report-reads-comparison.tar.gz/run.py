import datetime,hashlib,json,os,pathlib,re,signal,subprocess,time
base=pathlib.Path('/tmp/chough-report-reads-comparison'); root=pathlib.Path('/tmp/chough-report-reads-frozen-825a380'); source=pathlib.Path('/tmp/chough-tickets-20261102-JAIhPp')
binaries={'before':pathlib.Path('/tmp/chough-ticket-profile-target/debug/chough'),'after':pathlib.Path('/tmp/chough-report-reads-target/debug/chough')}
commands=[('next',['next','--environment','local-macos-arm64']),('status',['status','--environment','local-macos-arm64']),('timing-filtered',['timing','--cycle','current','--stage','test','--json']),('timing-all',['timing','--cycle','all','--json']),('retention-preview',['evidence','prune'])]
def tree():
 result={}
 for prefix in ('.chough','.specsync'):
  for p in (root/prefix).rglob('*'):
   if p.is_file(): result[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
before=tree()
patch=subprocess.check_output(['git','diff','--binary','--','src/cases.rs','src/evidence.rs','src/main.rs'],cwd=source)
(base/'implementation.patch').write_bytes(patch)
meta={'fixture_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'fixture':str(root),'fixture_clean_before':not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(),'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'source_patch_sha256':hashlib.sha256(patch).hexdigest(),'binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in binaries.items()},'profile':'fresh debug builds','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_timeout_seconds':1,'timing_budget_seconds':3,'command_timeout_seconds':15,'first_process_note':'New process; OS caches not evicted. Version order reversed for repeated runs.','inputs':{prefix:{'files':sum(1 for p in (root/prefix).rglob('*') if p.is_file()),'bytes':sum(p.stat().st_size for p in (root/prefix).rglob('*') if p.is_file())} for prefix in ('.chough/evidence','.chough/artifacts','.chough/cases','.specsync/archive/changes')}}
(base/'metadata.json').write_text(json.dumps(meta,indent=2))
results=[]
for kind in ('first-process','repeated'):
 for name,args in commands:
  order=('before','after') if kind=='first-process' else ('after','before')
  for version in order:
   label=kind+'-'+name+'-'+version; native=base/(label+'-native.jsonl');env=os.environ.copy();env.update({'PATH':'/tmp/chough-ticket32-profile/bin:/Users/leif/.cargo/bin:'+env['PATH'],'CHOUGH_TRACE':'1','CHOUGH_NATIVE_TIMEOUT_SECONDS':'1','CHOUGH_TIMING_NATIVE_BUDGET_SECONDS':'3','CHOUGH_PROFILE_NATIVE_LOG':str(native)})
   start=time.perf_counter();timeout=False
   with (base/(label+'.stdout')).open('wb') as out,(base/(label+'.stderr')).open('wb') as err:
    p=subprocess.Popen([str(binaries[version]),'--root',str(root),*args],env=env,stdout=out,stderr=err,start_new_session=True)
    try: code=p.wait(timeout=15)
    except subprocess.TimeoutExpired:
     timeout=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
   elapsed=time.perf_counter()-start
   trace=(base/(label+'.stderr')).read_text(errors='replace');calls=[json.loads(line) for line in native.read_text().splitlines()] if native.exists() else []
   starts=[v for v in calls if v['event']=='start'];ends=[v for v in calls if v['event']=='end'];counter=re.findall(r'case-suite loads=(\d+) lookups=(\d+) unique_ids=(\d+)',trace)
   result={'kind':kind,'command':name,'version':version,'seconds':elapsed,'returncode':code,'command_timed_out':timeout,'native_started':len(starts),'native_completed':len(ends),'completed_native_seconds':sum(v['seconds'] for v in ends) if ends else None,'native_trace':re.findall(r'native state=(\S+) elapsed_ms=(\d+)',trace),'case_counters':counter,'stdout_bytes':(base/(label+'.stdout')).stat().st_size}
   results.append(result);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(result),flush=True)
assert tree()==before,'managed records changed'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(),'fixture changed'
(base/'preservation.json').write_text(json.dumps({'managed_files':len(before),'byte_identical':True,'checkout_clean':True},indent=2))
for kind in ('first-process','repeated'):
 for name in ('next','status'):
  a=(base/(kind+'-'+name+'-before.stdout')).read_bytes();b=(base/(kind+'-'+name+'-after.stdout')).read_bytes()
  print('STDOUT_EQUAL',kind,name,a==b,flush=True)
print('FIXTURE_UNCHANGED',len(before),flush=True)

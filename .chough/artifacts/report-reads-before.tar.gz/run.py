import datetime,hashlib,json,os,pathlib,platform,signal,subprocess,time
base=pathlib.Path('/tmp/chough-ticket32-profile'); root=pathlib.Path('/tmp/chough-tickets-20261102-JAIhPp'); binary=pathlib.Path('/tmp/chough-ticket-profile-target/debug/chough')
commands=[('next',['next','--environment','local-macos-arm64']),('status',['status','--environment','local-macos-arm64']),('timing-filtered',['timing','--cycle','current','--stage','test','--json']),('timing-all',['timing','--cycle','all','--json']),('retention-preview',['evidence','prune'])]
meta={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'profile':'fresh debug build, cargo build --locked','platform':platform.platform(),'machine':platform.machine(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cold_definition':'first process invocation; OS filesystem cache was not evicted','source_checkout':str(root),'binary':str(binary),'native_timeout_seconds':10,'timing_budget_seconds':30,'command_timeout_seconds':45}
meta['input_groups']={}
for folder in ('.chough/evidence','.chough/artifacts','.chough/cases','.specsync/archive/changes'):
 files=[p for p in (root/folder).rglob('*') if p.is_file()]
 meta['input_groups'][folder]={'files':len(files),'bytes':sum(p.stat().st_size for p in files)}
(base/'metadata.json').write_text(json.dumps(meta,indent=2))
results=[]
for kind in ('first-process','warm'):
 for name,args in commands:
  label=kind+'-'+name; native=base/(label+'-native.jsonl'); env=os.environ.copy(); env.update({'PATH':str(base/'bin')+':/Users/leif/.cargo/bin:'+env['PATH'],'CHOUGH_TRACE':'1','CHOUGH_NATIVE_TIMEOUT_SECONDS':'10','CHOUGH_TIMING_NATIVE_BUDGET_SECONDS':'30','CHOUGH_PROFILE_NATIVE_LOG':str(native)})
  start=time.perf_counter(); timeout=False
  with (base/(label+'.stdout')).open('wb') as out, (base/(label+'.stderr')).open('wb') as err:
   p=subprocess.Popen([str(binary),'--root',str(root),*args],env=env,stdout=out,stderr=err,start_new_session=True)
   try: code=p.wait(timeout=45)
   except subprocess.TimeoutExpired:
    timeout=True; os.killpg(p.pid,signal.SIGKILL); code=p.wait()
  elapsed=time.perf_counter()-start
  calls=[json.loads(line) for line in native.read_text().splitlines()] if native.exists() else []
  starts=[v for v in calls if v['event']=='start']; ends=[v for v in calls if v['event']=='end']
  result={'kind':kind,'command':name,'args':args,'seconds':elapsed,'returncode':code,'command_timed_out':timeout,'native_started':len(starts),'native_completed':len(ends),'native_seconds':sum(v['seconds'] for v in ends),'stdout_bytes':(base/(label+'.stdout')).stat().st_size}
  results.append(result); (base/'results.json').write_text(json.dumps(results,indent=2)); print(json.dumps(result),flush=True)
print('CHECKOUT_STATUS',subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip(),flush=True)
